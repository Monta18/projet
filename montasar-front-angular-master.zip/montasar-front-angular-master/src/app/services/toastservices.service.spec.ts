import { TestBed } from '@angular/core/testing';

import { ToastservicesService } from './toastservices.service';

describe('ToastservicesService', () => {
  let service: ToastservicesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ToastservicesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
