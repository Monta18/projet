package com.example.gestionentreprise.Controller.ClientController;

import com.example.gestionentreprise.Entity.ClientEntity.ClientEntity;
import com.example.gestionentreprise.Entity.ColisEntity.ColisEntity;
import com.example.gestionentreprise.Services.ClientService.ClientService;
import com.example.gestionentreprise.Services.ColisService.ColisService;
import com.example.gestionentreprise.Value.ClientValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class ClientController {

    @Autowired
    private ClientService clientService;





    @GetMapping("/client")
    public List<ClientEntity> Get_All_Client()
    {



        return clientService.Get_All_Client();
    }

    @GetMapping("/client/{id}")
    public Optional<ClientEntity> GetClientById(@PathVariable Long id)
    {

        return clientService.GetClientById(id);
    }


    @PostMapping("/client")
    public void ADD_Client(@RequestBody ClientEntity client)
    {
        clientService.addClient(client);
    }

    @PutMapping("/client")
    public void updateClientById(@RequestBody ClientEntity client)
    {
        clientService.updateClientById(client);
    }


    @DeleteMapping("/client/{id}")
    public void DeleteClient(@PathVariable Long id)
    {
        clientService.DeleteClient(id);
    }


    @GetMapping("/clientE")
    public List<ClientValue> GetClientEmeteurAvecColis()
    {
        return clientService.GetClientEmeteurAvecColis();
    }

   /* @GetMapping("/clientR")
    public List<ClientEntity> GetClientRecepteurAvecColis()
    {
        return clientService.GetClientEmmeteurAvecColis();
    }*/


    @GetMapping("/clientColis/{id}")
    public ClientValue GetClientByIdWithColis(@PathVariable Long id)
    {

        return clientService.GetClientByIdWithColis(id);
    }

    @GetMapping("/clientName/{name}")
    public List<ClientEntity> GetClientByName(@PathVariable Optional<String> name)
    {

        return clientService.GetClientByName(name);
    }

}
