import { Client } from './client'
import { Camion } from './camion'
import { Stock } from './stock'

export class Colis {
    
    id:number

    barcode: ''
    emplacement: ''
    status: string
    date: ''
    prix: number
    payer: boolean
    payedwith:string
    poid: ''
    longeur: ''
    largeur: ''
    hauteur: ''
    recepteur:Client
    emetteur:Client
    departure:''
    destination:''
    camion:Camion
    stock:Stock
    distance:number
    virtualweight:number
    contreremboursement:number
    tarma:string

}
