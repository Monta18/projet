import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ColiComponent } from './coli.component';

describe('ColiComponent', () => {
  let component: ColiComponent;
  let fixture: ComponentFixture<ColiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ColiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ColiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
