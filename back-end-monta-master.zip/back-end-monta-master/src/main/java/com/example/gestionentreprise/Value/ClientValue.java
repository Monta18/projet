package com.example.gestionentreprise.Value;

import com.example.gestionentreprise.Entity.ClientEntity.ClientEntity;
import com.example.gestionentreprise.Entity.ColisEntity.ColisEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.CascadeType;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.Set;

public class ClientValue {

    private Long id;


    private String nom;


    private String representant;


    private String email;

    private String telephone;


    private String fax;

    private String site_web;

    private String adresse;

    private String typeClient;

    private Set<ColisEntity> colis;

    public ClientValue(Long id, String nom, String representant, String email, String telephone, String fax, String site_web, String adresse, String typeClient, Set<ColisEntity> colis) {
        this.id = id;
        this.nom = nom;
        this.representant = representant;
        this.email = email;
        this.telephone = telephone;
        this.fax = fax;
        this.site_web = site_web;
        this.adresse = adresse;
        this.typeClient = typeClient;
        this.colis = colis;
    }

    public ClientValue() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getRepresentant() {
        return representant;
    }

    public void setRepresentant(String representant) {
        this.representant = representant;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getSite_web() {
        return site_web;
    }

    public void setSite_web(String site_web) {
        this.site_web = site_web;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getTypeClient() {
        return typeClient;
    }

    public void setTypeClient(String typeClient) {
        this.typeClient = typeClient;
    }

    public Set<ColisEntity> getColis() {
        return colis;
    }

    public void setColis(Set<ColisEntity> colis) {
        this.colis = colis;
    }
}
