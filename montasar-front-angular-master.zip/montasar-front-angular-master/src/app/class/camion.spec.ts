import { Camion } from './camion';

describe('Camion', () => {
  it('should create an instance', () => {
    expect(new Camion()).toBeTruthy();
  });
});
