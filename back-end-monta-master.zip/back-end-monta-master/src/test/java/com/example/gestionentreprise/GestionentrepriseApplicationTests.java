package com.example.gestionentreprise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionentrepriseApplicationTests {

	@Test
	void contextLoads() {
	}

}
