import { Colis } from './colis'
import { Employe } from './employe'

export class Camion {

    id:number
    nom:string
    maticule:string
    colis:Array<Colis>
    chauffer:Employe
    
}
