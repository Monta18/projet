import { Colis } from './colis'

export class Stock {
    id:number
    emplacement:string
    nom:string
    colis:Array<Colis>
    
}
