package com.example.gestionentreprise.Entity.CamionEntity;

import com.example.gestionentreprise.Entity.ColisEntity.ColisEntity;
import com.example.gestionentreprise.Entity.EmployeEntity.EmployeEntity;

import javax.persistence.*;
import java.util.Set;

@Entity
public class CamionEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String nom;


    private String maticule;

    @ManyToOne
    private EmployeEntity chauffer;

    @OneToMany(cascade = CascadeType.REMOVE,mappedBy = "camion" )
    private Set<ColisEntity> colis;

    public CamionEntity(EmployeEntity chauffer, String nom, String maticule, Set<ColisEntity> colis) {

        this.nom = nom;
        this.maticule = maticule;
        this.colis = colis;
        this.chauffer=chauffer;
    }

    public CamionEntity() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getMaticule() {
        return maticule;
    }

    public void setMaticule(String maticule) {
        this.maticule = maticule;
    }

    public Set<ColisEntity> getColis() {
        return colis;
    }

    public void setColis(Set<ColisEntity> colis) {
        this.colis = colis;
    }

    public EmployeEntity getChauffer() {
        return chauffer;
    }

    public void setChauffer(EmployeEntity chauffer) {
        this.chauffer = chauffer;
    }
}
