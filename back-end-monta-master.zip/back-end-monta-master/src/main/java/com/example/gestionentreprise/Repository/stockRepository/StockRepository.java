package com.example.gestionentreprise.Repository.stockRepository;

import com.example.gestionentreprise.Entity.stockEntity.StockEntity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StockRepository extends CrudRepository<StockEntity, Long> {
}
