package com.example.gestionentreprise.Services.ColisService;

import com.example.gestionentreprise.Entity.ColisEntity.ColisEntity;
import com.example.gestionentreprise.Repository.ColisRepository.ColisRepository;
import com.example.gestionentreprise.Services.ClientService.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ColisService {

    @Autowired
    private ColisRepository colisRepository;

    @Autowired
    private ClientService clientService;

    public List<ColisEntity> Get_All_Colis() {
        List<ColisEntity> colis =new ArrayList<>();
        colisRepository.findAll().forEach(colis::add);
        return colis;
    }

    public Optional<ColisEntity> GetColisById(Long id) {
        return colisRepository.findById(id);
    }

    public ColisEntity addColis(ColisEntity colis) {

        if(colis.getRecepteur().getTypeClient().equals("passager"))
        {
            Long id =clientService.addClient(colis.getRecepteur()).getId();
           colis.getRecepteur().setId(id);
        }
        if(colis.getEmetteur().getTypeClient().equals("passager"))
        {
            Long id =clientService.addClient(colis.getEmetteur()).getId();
            colis.getEmetteur().setId(id);

        }
       return colisRepository.save(colis);
    }

    public void updateColisById(ColisEntity colis) {
        colisRepository.save(colis);
    }

    public void DeleteColis(Long id) {
        colisRepository.deleteById(id);
    }
}
