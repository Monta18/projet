import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { HttpservicesService } from '../services/httpservices.service';
import { Client } from '../class/client';
import { Colis } from '../class/colis';
import { ToastservicesService } from '../services/toastservices.service';
import { Produit } from '../class/produit';
import { Stock } from '../class/stock';




@Component({
  selector: 'app-coli',
  templateUrl: './coli.component.html',
  styleUrls: ['./coli.component.scss']
})


export class ColiComponent implements OnInit {

  constructor(private toast:ToastservicesService, private route: ActivatedRoute, private httpservice: HttpservicesService) { }


  list_client: Array<Client>
  list_product:Array<Produit>
  list_stock:Array<Stock>
  product_to_add:Produit;

  colis: Colis;

  client_passager_emetteur: Client;
  client_passager_recepteur: Client;


  type;

  client_sender_type = { 'type': 'no' }
  client_reciver_type = { 'type': 'no' }




  ngOnInit(): void {
  this.colis=new Colis();



  this.product_to_add=new Produit();
  this.list_product=new Array<Produit>();
  this.colis.prix =0
  this.product_to_add.prix=0;
  this.client_passager_emetteur=new Client();
  this.client_passager_recepteur=new Client();
  this.client_passager_emetteur.typeClient="passager";
  this.client_passager_recepteur.typeClient="passager";
  this.colis.payer=true;
  this.list_stock=new Array<Stock>();
  
    this.route.queryParams.subscribe(params => {

      this.type = params["type"];


    })
    this.httpservice.get('client').subscribe(data => {

      this.list_client = data;
      
    })
    this.httpservice.get("stock").subscribe(data=>
      {
        this.list_stock=data;
      })



  }
 

  change_client_sender(type) {
    this.client_sender_type.type = type;
    if (type == 'pro') {
      this.colis.emetteur=new Client();
    }
    else {
      this.colis.emetteur=this.client_passager_emetteur;
    }
  }

  change_client_reciver(type) {
    this.client_reciver_type.type = type;

    if (type == 'pro') {
      this.colis.recepteur=new Client();
    }
    else {

      this.colis.recepteur=this.client_passager_recepteur;
    }
  }

  select_client_emetteur_pro(client)
  {
    this.colis.emetteur=this.list_client.filter(id=> id['id']==client)[0];
  }

  select_client_recepteur_pro(client)
  {
 
     this.colis.recepteur=this.list_client.filter(id=> id['id']==client)[0];

  }
  change_stock(x)
  {
    this.colis.stock=this.list_stock.filter(id=> id["id"]==x)[0];
 
  }

  ajouter_colis()
  {
    this.colis.status="en attente";
    this.colis.emplacement=this.colis.departure;

    console.log(this.colis);
   this.httpservice.post(this.colis,'colis').subscribe(data=>{


    
    this.colis=data;
    console.log(this.colis.id)
      this.toast.showSuccess('la colis a ete enregistre');
    },error=>
    {
      this.toast.showError("error a l'ajoute de colis");
    }) 
  }

  addproduct()
  {
    this.list_product.push(this.product_to_add);
    this.colis.prix += this.product_to_add.prix;
    this.product_to_add=new Produit();
    this.toast.showSuccess("produit a ete ajouter")
   
  }

  delet_from_list(index)
  {

    this.colis.prix -= this.list_product[index].prix;
    this.list_product.splice(index, 1);
  }


  show_facture() {


}



 printDiv(divName) {
  var printContents = document.getElementById(divName).innerHTML;
  var originalContents = document.body.innerHTML;

  document.body.innerHTML = printContents;

  window.print();

  document.body.innerHTML = originalContents;
}
}
