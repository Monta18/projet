package com.example.gestionentreprise.Services.EmployeService;

import com.example.gestionentreprise.Entity.ClientEntity.ClientEntity;
import com.example.gestionentreprise.Entity.EmployeEntity.EmployeEntity;
import com.example.gestionentreprise.Repository.ColisRepository.ColisRepository;
import com.example.gestionentreprise.Repository.EmployeRepository.EmployeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Service
public class EmployeService {

    @Autowired
    private EmployeRepository employeRepository;

    public Optional<EmployeEntity> GetEmployeyId(Long id) {

        return employeRepository.findById(id);
    }

    public List<EmployeEntity> Get_All_employe() {
        List<EmployeEntity> employes =new ArrayList<>();
        employeRepository.findAll().forEach(employes::add);
        return employes;
    }

    public void addEmploye(EmployeEntity employe) {
        employeRepository.save(employe);
    }

    public void updateEmployeById(EmployeEntity employe) {
        employeRepository.save(employe);
    }

    public void DeleteEmploye(Long id) {
        employeRepository.deleteById(id);
    }

    public List<EmployeEntity> GetEmployeByName(Optional<String> name) {

        return employeRepository.findByNomContaining(name);
    }
}
