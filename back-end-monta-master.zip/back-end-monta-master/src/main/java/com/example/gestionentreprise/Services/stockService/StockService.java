package com.example.gestionentreprise.Services.stockService;

import com.example.gestionentreprise.Entity.stockEntity.StockEntity;
import com.example.gestionentreprise.Repository.stockRepository.StockRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class StockService {
    @Autowired
    private StockRepository stockRepository;

    public List<StockEntity> Get_All_Stock() {
        List<StockEntity> stock =new ArrayList<>();
        stockRepository.findAll().forEach(stock::add);
        return stock;
    }

    public Optional<StockEntity> GetStocksById(Long id) {
        return stockRepository.findById(id);
    }

    public void addStock(StockEntity stock) {
        stockRepository.save(stock);
    }

    public void updateStockById(StockEntity stock) {
        stockRepository.save(stock);
    }

    public void DeleteStock(Long id) {
        stockRepository.deleteById(id);
    }
}
