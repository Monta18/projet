package com.example.gestionentreprise.Entity.EmployeEntity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Date;

@Entity
public class EmploiEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private Date date;

    private String heureDebut;

    private String heureFin;

    @ManyToOne
    @JsonIgnore
    private EmployeEntity employee;

    public EmploiEntity(Date date, String heureDebut, String heureFin, EmployeEntity employee) {
        this.date = date;
        this.heureDebut = heureDebut;
        this.heureFin = heureFin;
        this.employee = employee;
    }

    public EmploiEntity() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getHeureDebut() {
        return heureDebut;
    }

    public void setHeureDebut(String heureDebut) {
        this.heureDebut = heureDebut;
    }

    public String getHeureFin() {
        return heureFin;
    }

    public void setHeureFin(String heureFin) {
        this.heureFin = heureFin;
    }

    public EmployeEntity getEmployee() {
        return employee;
    }

    public void setEmployee(EmployeEntity employee) {
        this.employee = employee;
    }
}
