export class Employe {

    id:number
    nom:string
    prenom:string
    cin:string
    poste:string
    nbrHeureParMois:number
    salaire:number
}
