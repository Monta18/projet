package com.example.gestionentreprise.Entity.EmployeEntity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Date;

@Entity
public class CongeEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private Date dateDebut;

    private Date dateFin;

    private String raison;

    @ManyToOne
    @JsonIgnore
    private EmployeEntity employe;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getDateDebut() {
        return dateDebut;
    }

    public void setDateDebut(Date dateDebut) {
        this.dateDebut = dateDebut;
    }

    public Date getDateFin() {
        return dateFin;
    }

    public void setDateFin(Date dateFin) {
        this.dateFin = dateFin;
    }

    public EmployeEntity getEmployeEntity() {
        return employe;
    }

    public void setEmployeEntity(EmployeEntity employeEntity) {
        this.employe = employeEntity;
    }

    public String getRaison() {
        return raison;
    }

    public void setRaison(String raison) {
        this.raison = raison;
    }

    public EmployeEntity getEmploye() {
        return employe;
    }

    public void setEmploye(EmployeEntity employe) {
        this.employe = employe;
    }

    public CongeEntity() {

    }

    public CongeEntity(Date dateDebut, Date dateFin, String raison, EmployeEntity employe) {
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
        this.raison = raison;
        this.employe = employe;
    }
}
