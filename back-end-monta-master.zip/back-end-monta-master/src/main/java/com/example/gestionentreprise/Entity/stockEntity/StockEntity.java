package com.example.gestionentreprise.Entity.stockEntity;

import com.example.gestionentreprise.Entity.ColisEntity.ColisEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Set;

@Entity
public class StockEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String emplacement;


    private String nom;


    @OneToMany(cascade = CascadeType.REMOVE,mappedBy = "stock" )
    private Set<ColisEntity> colis;

    public StockEntity(  String emplacement, String nom, Set<ColisEntity> colis) {

        this.emplacement = emplacement;
        this.nom = nom;
        this.colis = colis;
    }

    public StockEntity() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmplacement() {
        return emplacement;
    }

    public void setEmplacement(String emplacement) {
        this.emplacement = emplacement;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Set<ColisEntity> getColis() {
        return colis;
    }

    public void setColis(Set<ColisEntity> colis) {
        this.colis = colis;
    }
}
