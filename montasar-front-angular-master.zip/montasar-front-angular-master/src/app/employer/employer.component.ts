import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employer',
  templateUrl: './employer.component.html',
  styleUrls: ['./employer.component.scss']
})
export class EmployerComponent implements OnInit {


  jours=['lundi','mardi','mecredi','jeudi','vendredi','samedi','dimanche']
  constructor() { }

  ngOnInit(): void {
  }

}
