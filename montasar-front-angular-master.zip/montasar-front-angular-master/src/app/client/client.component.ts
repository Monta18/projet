import { Component, OnInit } from '@angular/core';

import { ActivatedRoute } from '@angular/router';
import { HttpservicesService } from '../services/httpservices.service';
import { ToastservicesService } from '../services/toastservices.service';
import { Client } from '../class/client';
import { Colis } from '../class/colis';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.scss']
})
export class ClientComponent implements OnInit {

  constructor( private route: ActivatedRoute,private httpservice:HttpservicesService,private toast:ToastservicesService) { }
  client : Client;

  type;
  titre = 'suivis';

  transaction_type;
  list_colis=Array<Colis>();
  list_client=Array<Client>();

  colis_details:Colis;

  ngOnInit(): void {
    // this.showSuccess()

    this.client=new Client();
    this.colis_details=new Colis();
    this.route.queryParams.subscribe(params => {

      this.type = params["type"];
      if(this.type=="suivis")
      {
        this.list_colis=new Array<Colis>();
        this.httpservice.get('colis').subscribe(data=>
          {
            this.list_colis=data;
            // console.log(this.list_colis)
          })
      }
      else if(this.type=="list")
      {
        this.list_client=new Array<Client>();
        this.httpservice.get('client').subscribe(data=>
          {
            this.list_client=data;
            // console.log(this.list_client)
          })
      }


    })
  }

  delet_colis(i,id)
  {
    
    this.httpservice.delete("colis/"+id).subscribe(data=>
      {
        
        this.toast.showSuccess('colis a ete supprimer');
        this.list_colis.splice(i,1);

      }, error=>
      {
        this.toast.showError('error supprimer colis');
      })
  }

  add_client()
  {
    this.client.typeClient="profissional";
   

    this.httpservice.post(this.client,'client').subscribe(data=>
      {
    
        this.toast.showSuccess('client a ete ajouter');
        this.client=new Client();
      },error=>
      {
        this.toast.showSuccess('error a ajouter le client');
      }
      )

  }


  choisir_filier_transaction(type) {


    this.transaction_type = type;
  }

  details(colis){

    this.colis_details=colis;

  }

  

}
