import { Colis } from './colis';

describe('Colis', () => {
  it('should create an instance', () => {
    expect(new Colis()).toBeTruthy();
  });
});
