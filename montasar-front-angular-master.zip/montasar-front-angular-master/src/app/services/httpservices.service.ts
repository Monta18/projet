import { Injectable } from '@angular/core';
import { Observable } from "rxjs";
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class HttpservicesService {
  baseurl = "http://localhost:8080/";

  httpheader = new HttpHeaders({ "Content-Type": "application/json" });
  constructor( private http: HttpClient) { }





  post(type, tab: string): Observable<any> {
    const body = type;

    return this.http.post(this.baseurl + tab, body, {
      headers: this.httpheader
    });
  }

  post2(type, tab: string): Observable<any> {
    const body = type;

    return this.http.post(this.baseurl + tab, body);
  }

  put2(type, tab: string): Observable<any> {
    const body = type;

    return this.http.put(this.baseurl + tab, body);
  }
  get(tab: string): Observable<any> {
    return this.http.get(this.baseurl + tab, { headers: this.httpheader });
  }

  delete(tab: string): Observable<any> {
    return this.http.delete(this.baseurl + tab, { headers: this.httpheader });
  }
  put(type, tab: string): Observable<any> {
    const body = type;

    return this.http.put(this.baseurl + tab, body, {
      headers: this.httpheader
    });
  }
}
