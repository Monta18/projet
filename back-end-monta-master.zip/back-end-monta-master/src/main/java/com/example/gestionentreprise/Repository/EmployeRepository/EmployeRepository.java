package com.example.gestionentreprise.Repository.EmployeRepository;

import com.example.gestionentreprise.Entity.ClientEntity.ClientEntity;
import com.example.gestionentreprise.Entity.EmployeEntity.EmployeEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface EmployeRepository extends CrudRepository<EmployeEntity,Long> {

    List<EmployeEntity> findByNomContaining (Optional<String> nom);
}
