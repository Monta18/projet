import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class ToastservicesService {

  constructor(private toastr: ToastrService) { }

  showSuccess(msg) {
    this.toastr.success(msg, 'succes!');
  }

  showError(msg) {
    this.toastr.error(msg, 'error!');
  }
}
