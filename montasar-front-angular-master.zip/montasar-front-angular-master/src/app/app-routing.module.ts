import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { StockComponent } from './stock/stock.component';
import { ColiComponent } from './coli/coli.component';
import { EmployerComponent } from './employer/employer.component';
import { ClientComponent } from './client/client.component';
import { ConnexionComponent } from './connexion/connexion.component';
import { HistoriqueComponent } from './historique/historique.component';
import { TransportComponent } from './transport/transport.component';


const routes: Routes = [


 
  
      { path: '', component: HomeComponent },
      { path: 'home', component: HomeComponent },

      // { path: ':nom/:id', component: PageCategoryComponent },

      { path: 'stock', component: StockComponent },

      { path: 'colis', component: ColiComponent },
      { path: 'employer', component: EmployerComponent },


      { path: 'client', component: ClientComponent },
      { path: 'transport', component: TransportComponent },
      { path: 'historique', component: HistoriqueComponent },

      { path: 'connexion', component: ConnexionComponent },
   
   

 




  { path: '**', redirectTo: '/accueil', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
