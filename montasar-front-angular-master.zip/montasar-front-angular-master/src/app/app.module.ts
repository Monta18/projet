import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ClientComponent } from './client/client.component';
import { EmployerComponent } from './employer/employer.component';
import { StockComponent } from './stock/stock.component';
import { BoardComponent } from './board/board.component';
import { ColiComponent } from './coli/coli.component';
import { ConnexionComponent } from './connexion/connexion.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
 import { ToastrModule } from 'ngx-toastr';
import { CommonModule } from '@angular/common';
import { HistoriqueComponent } from './historique/historique.component';
import { TransportComponent } from './transport/transport.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxBarcode6Module } from 'ngx-barcode6';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ClientComponent,
    EmployerComponent,
    StockComponent,
    BoardComponent,
    ColiComponent,
    ConnexionComponent,
    HistoriqueComponent,
    TransportComponent,
  

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxBarcode6Module,
    CommonModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule, // required animations module
    ToastrModule.forRoot() 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
