import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Camion } from '../class/camion';
import { HttpservicesService } from '../services/httpservices.service';
import { ToastservicesService } from '../services/toastservices.service';

@Component({
  selector: 'app-transport',
  templateUrl: './transport.component.html',
  styleUrls: ['./transport.component.scss']
})
export class TransportComponent implements OnInit {

  constructor(private toastr: ToastservicesService,private route: ActivatedRoute,private http:HttpservicesService) { }


  type;

  show_data_camion=false;
  camion_add:Camion;
  list_camion:Array<Camion>;
  camion_to_show:Camion;

  ngOnInit(): void {
   this.list_camion=new Array<Camion>();
   this.camion_to_show=new Camion();
this.camion_add=new Camion();
  
   this.route.queryParams.subscribe(params => {

     this.type = params["type"];
   

   })
   this.get_all_camion();


 }

 get_all_camion()
 {
  this.http.get('camion').subscribe(data=>
    {
      this.list_camion=data;
    })
 }

 choisir_camion(index)
 {
   this.show_data_camion=true;
   this.camion_to_show=this.list_camion[index];

 }

add_camion()
{
  this.http.post(this.camion_add,'camion').subscribe(data=>
    {
      console.log(data)
      this.toastr.showSuccess("le camion a ete ajouter ")
      this.camion_add=new Camion();
      this.get_all_camion()
    },error=>
    {
      this.toastr.showError("error a la jouter de al camion")
    })
}




}
