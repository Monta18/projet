package com.example.gestionentreprise.Controller.CamionController;

import com.example.gestionentreprise.Entity.CamionEntity.CamionEntity;
import com.example.gestionentreprise.Entity.stockEntity.StockEntity;
import com.example.gestionentreprise.Services.CamionService.CamionService;
import com.example.gestionentreprise.Services.stockService.StockService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class CamionController {
    @Autowired
    private CamionService camionService;


    @GetMapping("/camion")
    public List<CamionEntity> Get_All_camion()
    {

        return camionService.Get_All_camion();

    }

    @GetMapping("/camion/{id}")
    public Optional<CamionEntity> GetCamionById(@PathVariable Long id)
    {

        return camionService.GetCamionsById(id);
    }


    @PostMapping("/camion")
    public void ADD_Camion(@RequestBody CamionEntity Camion)
    {
        camionService.addCamion(Camion);
    }

    @PutMapping("/camion")
    public void updateCamionById(@RequestBody CamionEntity Camion)
    {
        camionService.updateCamionById(Camion);
    }


    @DeleteMapping("/camion/{id}")
    public void DeleteCamion(@PathVariable Long id)
    {
        camionService.DeleteCamion(id);
    }

}
