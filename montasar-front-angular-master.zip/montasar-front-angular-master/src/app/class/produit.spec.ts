import { Produit } from './produit';

describe('Produit', () => {
  it('should create an instance', () => {
    expect(new Produit()).toBeTruthy();
  });
});
