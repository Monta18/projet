import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute } from '@angular/router';
import { Stock } from '../class/stock';
import { HttpservicesService } from '../services/httpservices.service';
import { ToastservicesService } from '../services/toastservices.service';
import { Colis } from '../class/colis';

@Component({
  selector: 'app-stock',
  templateUrl: './stock.component.html',
  styleUrls: ['./stock.component.scss']
})
export class StockComponent implements OnInit {


  stock:Stock;
  list_stock=Array<Stock>();
  list_colis=Array<Colis>();
  constructor(private route: ActivatedRoute,private httpservice:HttpservicesService,private toast:ToastservicesService) { }


   type;

   show_data_stock=false;

   ngOnInit(): void {
   
    this.route.queryParams.subscribe(params => {

      this.type = params["type"];
    

    })
    this.stock=new Stock();
    this.list_stock=new Array<Stock>();
    this.httpservice.get('stock').subscribe(data=>
      {
        this.list_stock=data;
      })

      this.list_colis=new Array<Colis>();

  }


  choisir_filier_stock(id)
  {
this.httpservice.get("stock/"+id).subscribe(data=>
  {
    this.list_colis=data["colis"];
    console.log(this.list_colis)
  })
   
    this.show_data_stock=true;
  }



  add_stock()
  {

    this.httpservice.post(this.stock,"stock").subscribe(data=>
      {
        this.toast.showSuccess("nouveau stock a ete ajouter ")

        this.list_stock.push(this.stock);
        this.stock=new Stock();
      },error=>
      {
        this.toast.showError("error ajouter stock")
      })

  }

}
