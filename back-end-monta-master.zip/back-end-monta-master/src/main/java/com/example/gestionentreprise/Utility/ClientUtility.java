package com.example.gestionentreprise.Utility;

import com.example.gestionentreprise.Entity.ClientEntity.ClientEntity;
import com.example.gestionentreprise.Value.ClientValue;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class ClientUtility {

    public ClientValue toValue(Optional<ClientEntity> eClient){
        ClientValue vClient=new ClientValue();
        vClient.setId(eClient.get().getId());
        vClient.setAdresse(eClient.get().getAdresse());
        vClient.setEmail(eClient.get().getEmail());
        vClient.setFax(eClient.get().getFax());
        vClient.setNom(eClient.get().getNom());
        vClient.setRepresentant(eClient.get().getRepresentant());
        vClient.setSite_web(eClient.get().getSiteweb());
        vClient.setTelephone(eClient.get().getTelephone());
        vClient.setTypeClient(eClient.get().getTypeClient());
        vClient.setColis(eClient.get().getColis());

        return vClient;

    }
}
