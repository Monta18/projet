package com.example.gestionentreprise.Repository.ColisRepository;

import com.example.gestionentreprise.Entity.ColisEntity.ColisEntity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;
import java.util.UUID;

@Repository
public interface ColisRepository extends CrudRepository<ColisEntity, Long>{
    public Set<ColisEntity>  findByEmetteurIdOrRecepteurId(Long emetteurId,Long recepteurId);

}
