package com.example.gestionentreprise.Entity.EmployeEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Entity
public class EmployeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    private String nom;

    @NotNull
    private String prenom;

    @NotNull
    private String cin;

    @NotNull
    private String poste;

    private Long nbrHeureParMois;

    private Long salaire;


    private String emploiDept;



    @OneToMany(mappedBy = "employe", cascade = CascadeType.ALL)
    private Set<CongeEntity> conge;

    @OneToMany(mappedBy = "employee", cascade = CascadeType.ALL)
    private Set<EmploiEntity> emploi;

    public EmployeEntity() {
    }

    public EmployeEntity(@NotNull String nom, @NotNull String prenom, @NotNull String cin, @NotNull String poste, Long nbrHeureParMois, Long salaire, String emploiDept, Set<CongeEntity> conge, Set<EmploiEntity> emploi) {
        this.nom = nom;
        this.prenom = prenom;
        this.cin = cin;
        this.poste = poste;
        this.nbrHeureParMois = nbrHeureParMois;
        this.salaire = salaire;
        this.emploiDept = emploiDept;
        this.conge = conge;
        this.emploi = emploi;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getCin() {
        return cin;
    }

    public void setCin(String cin) {
        this.cin = cin;
    }

    public String getPoste() {
        return poste;
    }

    public void setPoste(String poste) {
        this.poste = poste;
    }

    public Long getNbrHeureParMois() {
        return nbrHeureParMois;
    }

    public void setNbrHeureParMois(Long nbrHeureParMois) {
        this.nbrHeureParMois = nbrHeureParMois;
    }

    public Long getSalaire() {
        return salaire;
    }

    public void setSalaire(Long salaire) {
        this.salaire = salaire;
    }

    public String getEmploiDept() {
        return emploiDept;
    }

    public void setEmploiDept(String emploiDept) {
        this.emploiDept = emploiDept;
    }

    public Set<CongeEntity> getConge() {
        return conge;
    }

    public void setConge(Set<CongeEntity> conge) {
        this.conge = conge;
    }

    public Set<EmploiEntity> getEmploi() {
        return emploi;
    }

    public void setEmploi(Set<EmploiEntity> emploi) {
        this.emploi = emploi;
    }
}
