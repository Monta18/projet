export class Produit {


    prix: number
    poid: number
    longeur: number
    largeur: number
    hauteur: number


}
