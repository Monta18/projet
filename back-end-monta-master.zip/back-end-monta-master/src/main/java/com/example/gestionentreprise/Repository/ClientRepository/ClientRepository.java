package com.example.gestionentreprise.Repository.ClientRepository;

import com.example.gestionentreprise.Entity.ClientEntity.ClientEntity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ClientRepository extends CrudRepository<ClientEntity,Long> {


    List<ClientEntity> findAllByTypeClient(String type);

    List<ClientEntity> findByNomContaining(Optional<String> nom);
}
