package com.example.gestionentreprise.Entity.ClientEntity;

import com.example.gestionentreprise.Entity.ColisEntity.ColisEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import java.util.Set;
import javax.persistence.*;


@Entity
public class ClientEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;


    private String nom;


    private String representant;


    private String email;


    @NotNull
    private String telephone;


    private String fax;

    private String siteweb;

    private String adresse;

    @NotNull
    private String typeClient;

    @OneToMany(cascade = CascadeType.REMOVE)
    @JsonIgnore
    private Set<ColisEntity> colis;


    public ClientEntity() {
    }

    public ClientEntity( String nom, String representant,  String email, @NotNull String telephone, String fax, String siteweb, String adresse, @NotNull String typeClient, Set<ColisEntity> colis) {
        this.nom = nom;
        this.representant = representant;
        this.email = email;
        this.telephone = telephone;
        this.fax = fax;
        this.siteweb = siteweb;
        this.adresse = adresse;
        this.typeClient = typeClient;
        this.colis = colis;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getRepresentant() {
        return representant;
    }

    public void setRepresentant(String representant) {
        this.representant = representant;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getSiteweb() {
        return siteweb;
    }

    public void setSiteweb(String siteweb) {
        this.siteweb = siteweb;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getTypeClient() {
        return typeClient;
    }

    public void setTypeClient(String typeClient) {
        this.typeClient = typeClient;
    }

    public Set<ColisEntity> getColis() {
        return colis;
    }

    public void setColis(Set<ColisEntity> colis) {
        this.colis = colis;
    }


}


