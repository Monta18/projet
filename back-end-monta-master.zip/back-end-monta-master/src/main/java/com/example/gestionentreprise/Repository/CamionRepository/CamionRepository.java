package com.example.gestionentreprise.Repository.CamionRepository;

import com.example.gestionentreprise.Entity.CamionEntity.CamionEntity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CamionRepository extends CrudRepository<CamionEntity,Long>{
}
