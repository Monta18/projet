package com.example.gestionentreprise.Services.CamionService;

import com.example.gestionentreprise.Entity.CamionEntity.CamionEntity;
import com.example.gestionentreprise.Entity.stockEntity.StockEntity;
import com.example.gestionentreprise.Repository.CamionRepository.CamionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CamionService {
    @Autowired
    private CamionRepository camionRepository;


    public List<CamionEntity> Get_All_camion() {
        List<CamionEntity> camions =new ArrayList<>();
        camionRepository.findAll().forEach(camions::add);
        return camions;
    }

    public Optional<CamionEntity> GetCamionsById(Long id) {
        return camionRepository.findById(id);
    }

    public void addCamion(CamionEntity camion) {
        camionRepository.save(camion);
    }

    public void updateCamionById(CamionEntity camion) {
        camionRepository.save(camion);
    }

    public void DeleteCamion(Long id) {
        camionRepository.deleteById(id);
    }
}
