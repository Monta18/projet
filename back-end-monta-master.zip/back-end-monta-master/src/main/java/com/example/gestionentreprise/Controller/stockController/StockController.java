package com.example.gestionentreprise.Controller.stockController;

import com.example.gestionentreprise.Entity.ColisEntity.ColisEntity;
import com.example.gestionentreprise.Entity.stockEntity.StockEntity;
import com.example.gestionentreprise.Services.ColisService.ColisService;
import com.example.gestionentreprise.Services.stockService.StockService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class StockController {

    @Autowired
    private StockService stockService;


    @GetMapping("/stock")
    public List<StockEntity> Get_All_Stock()
    {

        return stockService.Get_All_Stock();
    }

    @GetMapping("/stock/{id}")
    public Optional<StockEntity> GetStockById(@PathVariable Long id)
    {

        return stockService.GetStocksById(id);
    }


    @PostMapping("/stock")
    public void ADD_Stock(@RequestBody StockEntity stock)
    {
        stockService.addStock(stock);
    }

    @PutMapping("/stock}")
    public void updateStockById(@RequestBody StockEntity stock)
    {
        stockService.updateStockById(stock);
    }


    @DeleteMapping("/stock/{id}")
    public void DeleteStock(@PathVariable Long id)
    {
        stockService.DeleteStock(id);
    }

}
