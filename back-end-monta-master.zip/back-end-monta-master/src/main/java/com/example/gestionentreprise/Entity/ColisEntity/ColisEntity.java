package com.example.gestionentreprise.Entity.ColisEntity;

import com.example.gestionentreprise.Entity.CamionEntity.CamionEntity;
import com.example.gestionentreprise.Entity.ClientEntity.ClientEntity;
import com.example.gestionentreprise.Entity.stockEntity.StockEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.Set;
import java.time.LocalDateTime;


@Entity
public class ColisEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    private Long barcode;

    @NotNull
    private String emplacement;

    private  String departure;
    private  String destination;

    private  String payedwith;



    @NotNull
    private String status;



    private LocalDateTime date=LocalDateTime.now();
    private Float prix;

    private Boolean payer;
    private Float contreremboursement;



    @NotNull
    private Float poid;


    private Float longueur;

    private Float largeur;

    private Float hauteur;

    private Float distnce;
    private Float virtualweight;
    private String tarma;


    @ManyToOne
    private StockEntity stock;

    @ManyToOne
    private CamionEntity camion;

    @ManyToOne
    private ClientEntity emetteur;
    @ManyToOne
    private ClientEntity recepteur;





    public ColisEntity() {

    }

    public ColisEntity(String tarma,Float virtualweight,Float contreremboursement,@NotNull Long barcode, @NotNull String emplacement, String departure, String destination, String payedwith, @NotNull String status, LocalDateTime date, Float prix, Boolean payer, @NotNull Float poid, Float longueur, Float largeur, Float hauteur, StockEntity stock, CamionEntity camion, ClientEntity emetteur, ClientEntity recepteur) {
        this.barcode = barcode;
        this.emplacement = emplacement;
        this.departure = departure;
        this.destination = destination;
        this.payedwith = payedwith;
        this.status = status;
        this.date = date;
        this.prix = prix;
        this.payer = payer;
        this.poid = poid;
        this.longueur = longueur;
        this.largeur = largeur;
        this.hauteur = hauteur;
        this.stock = stock;
        this.camion = camion;
        this.emetteur = emetteur;
        this.recepteur = recepteur;
        this.contreremboursement=contreremboursement;
        this.virtualweight=virtualweight;
        this.tarma=tarma;
    }

    public CamionEntity getCamion() {
        return camion;
    }

    public void setCamion(CamionEntity camion) {
        this.camion = camion;
    }

//    public StockEntity getStock() {
//        return stock;
//    }

    public void setStock(StockEntity stock) {
        this.stock = stock;
    }

    public Float getLongueur() {
        return longueur;
    }

    public void setLongueur(Float longueur) {
        this.longueur = longueur;
    }

    public Float getLargeur() {
        return largeur;
    }

    public void setLargeur(Float largeur) {
        this.largeur = largeur;
    }

    public Float getHauteur() {
        return hauteur;
    }

    public void setHauteur(Float hauteur) {
        this.hauteur = hauteur;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBarcode() {
        return barcode;
    }

    public void setBarcode(Long barcode) {
        this.barcode = barcode;
    }

    public String getEmplacement() {
        return emplacement;
    }

    public void setEmplacement(String emplacement) {
        this.emplacement = emplacement;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public Float getPrix() {
        return prix;
    }

    public void setPrix(Float prix) {
        this.prix = prix;
    }

    public Boolean getPayer() {
        return payer;
    }

    public void setPayer(Boolean payer) {
        this.payer = payer;
    }

    public Float getPoid() {
        return poid;
    }

    public void setPoid(Float poid) {
        this.poid = poid;
    }

    public String getDeparture() {
        return departure;
    }

    public void setDeparture(String departure) {
        this.departure = departure;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getPayedwith() {
        return payedwith;
    }

    public void setPayedwith(String payedwith) {
        this.payedwith = payedwith;
    }

    public ClientEntity getEmetteur() {
        return emetteur;
    }

    public void setEmetteur(ClientEntity emetteur) {
        this.emetteur = emetteur;
    }

    public ClientEntity getRecepteur() {
        return recepteur;
    }

    public void setRecepteur(ClientEntity recepteur) {
        this.recepteur = recepteur;
    }

//    public StockEntity getStock() {
//        return stock;
//    }

    public Float getContreremboursement() {
        return contreremboursement;
    }

    public void setContreremboursement(Float contreremboursement) {
        this.contreremboursement = contreremboursement;
    }

    public Float getDistnce() {
        return distnce;
    }

    public void setDistnce(Float distnce) {
        this.distnce = distnce;
    }

    public Float getVirtualweight() {
        return virtualweight;
    }

    public void setVirtualweight(Float virtualweight) {
        this.virtualweight = virtualweight;
    }

    public String getTarma() {
        return tarma;
    }

    public void setTarma(String tarma) {
        this.tarma = tarma;
    }
}
