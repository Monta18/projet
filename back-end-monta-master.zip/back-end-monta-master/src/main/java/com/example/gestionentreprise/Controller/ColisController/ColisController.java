package com.example.gestionentreprise.Controller.ColisController;

import com.example.gestionentreprise.Entity.ColisEntity.ColisEntity;

import com.example.gestionentreprise.Services.ColisService.ColisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Dictionary;
import java.util.List;
import java.util.Optional;


@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class ColisController {

    @Autowired
    private ColisService colisService;


    @GetMapping("/colis")
    public List<ColisEntity> Get_All_Colis()
    {

        return colisService.Get_All_Colis();
    }

    @GetMapping("/colis/{id}")
    public Optional<ColisEntity> GetColisById(@PathVariable Long id)
    {

        return colisService.GetColisById(id);
    }


    @PostMapping("/colis")
    public ColisEntity ADD_Colis(@RequestBody ColisEntity colis)
    {
        return colisService.addColis(colis);
    }

    @PutMapping("/colis}")
    public void updateColisById(@RequestBody ColisEntity colis)
    {
        colisService.updateColisById(colis);
    }


    @DeleteMapping("/colis/{id}")
    public void DeleteColis(@PathVariable Long id)
    {
        colisService.DeleteColis(id);
    }


}
