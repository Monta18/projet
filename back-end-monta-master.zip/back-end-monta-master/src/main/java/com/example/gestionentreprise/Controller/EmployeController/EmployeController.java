package com.example.gestionentreprise.Controller.EmployeController;

import com.example.gestionentreprise.Entity.ClientEntity.ClientEntity;
import com.example.gestionentreprise.Entity.EmployeEntity.EmployeEntity;
import com.example.gestionentreprise.Services.EmployeService.EmployeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class EmployeController {


    @Autowired
    private EmployeService employeService;





    @GetMapping("/employe")
    public List<EmployeEntity> Get_All_Employe()
    {



        return employeService.Get_All_employe();
    }

    @GetMapping("/employe/{id}")
    public Optional<EmployeEntity> GetEmployeById(@PathVariable Long id)
    {

        return employeService.GetEmployeyId(id);
    }


    @PostMapping("/employe")
    public void ADD_Employe(@RequestBody EmployeEntity employe)
    {
        employeService.addEmploye(employe);
    }

    @PutMapping("/employe")
    public void updateEmployeById(@RequestBody EmployeEntity employe)
    {
        employeService.updateEmployeById(employe);
    }


    @DeleteMapping("/employe/{id}")
    public void DeleteEmploye(@PathVariable Long id)
    {
        employeService.DeleteEmploye(id);
    }


    @GetMapping("/employeName/{name}")
    public List<EmployeEntity> GetEmployeByName(@PathVariable Optional<String> name)
    {

        return employeService.GetEmployeByName(name);
    }



}
