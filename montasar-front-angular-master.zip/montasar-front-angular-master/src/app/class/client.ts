export class Client {

        id:number
        nom: ''
        representant: ''
        email: ''
        telephone: ''
        fax: ''
        siteweb: ''
        adresse: ''
        typeClient: string
        colis: Array<Client>

      
    
    
}
