package com.example.gestionentreprise.Services.ClientService;

import com.example.gestionentreprise.Entity.ClientEntity.ClientEntity;
import com.example.gestionentreprise.Entity.ColisEntity.ColisEntity;
import com.example.gestionentreprise.Repository.ClientRepository.ClientRepository;
import com.example.gestionentreprise.Repository.ColisRepository.ColisRepository;
import com.example.gestionentreprise.Utility.ClientUtility;
import com.example.gestionentreprise.Value.ClientValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ClientService {

    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private ColisRepository colisRepository;
    @Autowired
    private ClientUtility clientUtility;

    public List<ClientEntity> Get_All_Client() {
        List<ClientEntity> clients =new ArrayList<>();
        clientRepository.findAll().forEach(clients::add);
        return clients;
    }

    public Optional<ClientEntity> GetClientById(Long id) {
        return clientRepository.findById(id);
    }

    public ClientEntity addClient(ClientEntity client) {
        return  clientRepository.save(client);

    }

    public void updateClientById(ClientEntity client) {
        clientRepository.save(client);
    }

    public void DeleteClient(Long id) {
        clientRepository.deleteById(id);
    }

    public List<ClientValue> GetClientEmeteurAvecColis(){
        List<ClientValue> clients =new ArrayList<>();
        clientRepository.findAllByTypeClient("E").forEach((client)->{
            Set<ColisEntity> colis=new HashSet<>();
           // colis.add(colisRepository.findByEmetteurId(client.getId()));

            //System.out.println("client "+client.getId());

            ClientValue vClient=new ClientValue();
          //  vClient= clientUtility.toValue(client);
            vClient.setColis(colisRepository.findByEmetteurIdOrRecepteurId(client.getId(),client.getId()));

            clients.add(vClient);
        });
        return clients;


    }
    public List<ClientValue> GetClientEmmeteurAvecColis()
    {
        return null;
    }


    public ClientValue GetClientByIdWithColis(Long id) {
        Set<ColisEntity> colis=new HashSet<>();
        colisRepository.findByEmetteurIdOrRecepteurId(id,id).forEach(colis::add);
         Optional<ClientEntity> clt=clientRepository.findById(id);

         ClientValue client=clientUtility.toValue(clt);

         client.setColis(colis);

        return client;
    }

    public List<ClientEntity> GetClientByName(Optional<String> name) {

        return clientRepository.findByNomContaining(name);

    }
}
